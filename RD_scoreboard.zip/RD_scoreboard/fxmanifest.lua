fx_version "bodacious"
games {"gta5"}

ui_page 'html/index.html'

client_scripts {
    'client/main.lua',
} 

files {
    'html/index.html',
    'html/style.css',
    'html/reset.css',
    'html/app.js',
	'html/img/*.png',
	'html/img/*.gif',
    'html/fonts/BrittanySignature-LjyZ.otf'
}
server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/server.lua',
}
shared_scripts {
    'config.lua',
    'language.lua',
}

escrow_ignore {
	'config.lua',
    'language.lua',
    'server/server.lua',
    'client/main.lua',
}

lua54 'yes'