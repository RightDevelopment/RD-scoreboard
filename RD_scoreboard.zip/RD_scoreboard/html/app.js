$(function () {
    function Toggelitem(id, bool) {
        if (bool) {
            $(id).show();
        } else {
            $(id).hide();
        }
    }
    
    Toggelitem("#main", false)

    window.addEventListener('message', function (event) {
        var item = event.data;
        if (item.type === "main") {
            if (item.status == true) {
                FillPlayers(item.info.PlayersInfo)
                SetDutyCounts(item.info.dutyCounts)
                Toggelitem("#main", true)
            } else {
                Toggelitem("#main", false)
            }
        }
    })

    // if the person uses the escape key, it will exit the resource
    document.onkeyup = function (data) {
        if (data.which == 27) {
            $.post('http://RD_scoreboard/exit', JSON.stringify({}));
            return;
        }
    };

    function FillPlayers(players){
        document.getElementById("players_host").innerHTML = ""
        for(i = 0; i < players.length; i++){
            p = players[i]
            if (p.time == 1){
                base = '<div class="player_host">'+
                    '<h1 class="ply_info cfx">'+p.cfx+'</h1>'+
                    '<h1 class="ply_info elapsed">'+p.time+' minute</h1>'+
                    '<div class="hl hl_2"></div>'+
                    '<h1 class="char_info_title char_name">CHARACTER NAME</h1>'+
                    '<h1 class="char_info char_name">'+p.name+'</h1>'+
                    '<h1 class="char_info_title char_job">CHARACTER JOB</h1>'+
                    '<h1 class="char_info char_job">'+p.job+'</h1>'+
                '</div>';
            }else {
                base = '<div class="player_host">'+
                    '<h1 class="ply_info cfx">'+p.cfx+'</h1>'+
                    '<h1 class="ply_info elapsed">'+p.time+' minutes</h1>'+
                    '<div class="hl hl_2"></div>'+
                    '<h1 class="char_info_title char_name">CHARACTER NAME</h1>'+
                    '<h1 class="char_info char_name">'+p.name+'</h1>'+
                    '<h1 class="char_info_title char_job">CHARACTER JOB</h1>'+
                    '<h1 class="char_info char_job">'+p.job+'</h1>'+
                '</div>';
            }
            $("#players_host").append(base);
        }
    }

    function SetDutyCounts(dutyCounts){
        for(var t in dutyCounts){
            document.getElementsByClassName(t+"_box")[0].getElementsByClassName("job_amount_on_duty")[0].innerHTML = dutyCounts[t]
        }
    }
})