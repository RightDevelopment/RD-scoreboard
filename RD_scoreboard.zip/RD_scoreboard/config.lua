Config = {}

Config.Jobs = {
    ["police"] = {"police", "bcso"},
    ["ambulance"] = {"ambulance", "fire"},
    ["realestate"] = {"realestate"},
    ["lawyer"] = {"lawyer"},
    ["judge"] = {"judge"},
    ["cardealer"] = {"cardealer"},
    ["mechanic"] = {"mechanic"},
    ["tow"] = {"tow"},
    ["taxi"] = {"taxi"},
}