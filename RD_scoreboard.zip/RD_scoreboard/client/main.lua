QBCore = exports["qb-core"]:GetCoreObject()
display = false



RegisterCommand('scoreboard', function()
    QBCore.Functions.TriggerCallback("RDSB:callback:getscoreboardinfo", function(info)
        SetDisplay(not display, "main", info)
        while display do
            Wait(10000)
            QBCore.Functions.TriggerCallback("RDSB:callback:getscoreboardinfo", function(info)
                SetDisplay(true, "main", info)
            end)
        end
    end)
end, false)

RegisterKeyMapping('scoreboard', 'Open Scoreboard', 'keyboard', 212)

--------------------
----- Callback -----
--------------------

RegisterNUICallback("exit", function(data)
    SetDisplay(false, "main", nil)
end)

---------------------
----- Functions -----
---------------------

function SetDisplay(bool, pageType, item)
    display = bool
    SetNuiFocus(bool, bool)
    SendNUIMessage({
        type = pageType,
        status = bool,
        info = item,
    })
    return
end

function Sendmsg(pageType, item)
    SendNUIMessage({
        type = pageType,
        info = item,
    })
end

-------------------
----- Threads -----
-------------------

CreateThread(function()
    TriggerServerEvent("RDSB:server:playerjoined")
end)

------------------
----- Events -----
------------------

RegisterNetEvent("RDM:client:setdisplay", function(page, bool, info)
    if info == nil then info = {} end
    SetDisplay(bool, page, info)
end)

RegisterNetEvent("RDM:client:sendnuimsg", function(type, msg)
    Sendmsg(type, msg)
end)