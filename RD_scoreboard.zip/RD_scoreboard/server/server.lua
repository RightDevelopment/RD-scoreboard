QBCore = exports["qb-core"]:GetCoreObject()
joinTimes = {}

--------------------
----- Commands -----
--------------------

------------------
----- Thread -----
------------------

---------------------
----- Functions -----
---------------------

function ToInt(num)
    numS = tostring(num)
    rnum = 0
    for i = 1, #numS, 1 do
        if string.sub(numS, i, i) ~= '.' and string.sub(numS, i, i) ~= ',' then
            rnum = rnum * 10
            rnum = rnum + tonumber(string.sub(numS, i, i))
        else
            if #numS > i then
                if tonumber(string.sub(numS, i + 1, i + 1)) >= 5 then rnum = rnum + 1 end
            end
            break
        end
    end
    return rnum
end

function GetDutyCountForJobs()
    Players = QBCore.Functions.GetPlayers()
    dutyCounts = {}
    for i, jobs in pairs(Config.Jobs) do
        dutyCounts[i] = 0
        for x = 1, #jobs, 1 do
            for z = 1, #Players, 1 do
                p = QBCore.Functions.GetPlayer(Players[z])
                if p.PlayerData.job.name == jobs[x] and p.PlayerData.job.onduty then
                    dutyCounts[i] = dutyCounts[i] + 1
                end
            end
        end
    end
    return dutyCounts
end

---------------------
----- Callbacks -----
---------------------

QBCore.Functions.CreateCallback("RDSB:callback:getscoreboardinfo", function(source, cb)
    info = {}
    PlayersInfo = {}
    Players = QBCore.Functions.GetPlayers()
    for src, time in pairs(joinTimes) do
        Player = QBCore.Functions.GetPlayer(src)
        p = {}
        p.cfx = GetPlayerName(src)
        p.time = ToInt((os.time() - time) / 60)
        pfn = Player.PlayerData.charinfo.firstname
        pln = Player.PlayerData.charinfo.lastname
        p.name = string.upper(string.sub(pfn, 1, 1))..string.sub(pfn, 2, #pfn).." "..string.upper(string.sub(pln, 1, 1))..string.sub(pln, 2, #pln)
        p.job = Player.PlayerData.job.label
        table.insert(PlayersInfo, p)
    end
    info.PlayersInfo = PlayersInfo
    info.dutyCounts = GetDutyCountForJobs()
    cb(info)
end)

------------------
----- Events -----
------------------

RegisterNetEvent("RDSB:server:playerjoined", function()
    src = source
    time = os.time()
    joinTimes[src] = time
end)

RegisterNetEvent("playerDropped", function()
    src = source
    joinTimes[src] = nil
end)