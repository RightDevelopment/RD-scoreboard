1. Add the PD_Citation Resource from keymaster
2. Add the following items and images in itemImages:
['evidence_camera'] 		     = {['name'] = 'evidence_camera', 			    ['label'] = 'Evidence Camera', 			['weight'] = 0, 		['type'] = 'item', 		['image'] = 'evidence_camera.png', 			['unique'] = true, 		['useable'] = true, 	['shouldClose'] = false,   ['combinable'] = nil,   ['description'] = 'A Citation'},
3. Add this to a server script in qb-apartments, recomended in qb-apartments/server/main.lua (You can use other scripts just use this as a templete and make sure the callback gives all houses in the script where name is the unique identifier, label house label shown in the mdt and doorCoords where the waypoint will be set when you ping the house):
QBCore.Functions.CreateCallback("RDM:callback:gethouses", function(source, cb)
    src = source
    houses = {}
    for i, h in pairs(Apartments.Locations) do
        house = {}
        house.name = h.name
        house.label = h.label
        house.doorCoord = h.coords.enter
        table.insert(houses, house)
    end
    cb(houses)
end)
4. Ensure the config is to your liking:
    -make sure you set up a discord web hook on line 3
    -Make sure you set you inventoys item images location on line 9, by default it works with qb-inventory
5. Look throught the scripts in the shared folder ro ensure they are to your liking.
6. in shared/cameraPresets.lua you can setup cctv camera presets from props.
7. If you want to setup more cctv cameras use the following metod (Make sure the camera prop you want to use is setup in cameraPresets.lua):
    -If you want to reload all cameras on the entier map and delete the once that are provided use /setupcameras (This may take up to 30 min don't touch anything while doing this. I also recomend being alone in the server may cause issues if you are more the one person not tested)
    -This is the recomended metod. By using /setuplocalcameras it will setup cameras sourunding you and will make sure no duplicates are added so dont worry about that.
    -If you want to change a specific camera you can do so in the cameras.lua
8. Add this to qb-inventory/server/main.lua:
    At line 2090: TriggerEvent("RDM:server:RegisterFriearm", src, itemData)
    At line 2113: TriggerEvent("RDM:server:RegisterFriearm", src, itemData)
    At line 2124: TriggerEvent("RDM:server:RegisterFriearm", src, itemData)
